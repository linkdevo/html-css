
public class Cliente
{
    private int codigo;
    private String nome;
    private String telefone;
    
    public Cliente (int c, String n, String t){
        codigo = c;
        nome = n;
        telefone = t;
    }
    
    public String getNome(){
        return nome;
    }
    
    public String getTelefone(){
        return telefone;
    }

}
