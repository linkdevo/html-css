
public class Aluguel
{
    //atributos
    private int codigo;
    private String dataInicio;
    private String dataFim;
    private Imovel imovel; // associação simples da classe Aluguel com a classe Imovel
    private Cliente cliente; //associação simples com a classe Cliente
    
    //construtor
    public Aluguel(int c, String dI, String dF, Imovel i, Cliente cl){
        codigo = c;
        dataInicio = dI;
        dataFim = dF;
        imovel = i;
        cliente = cl;
    }
    
    public void exibeDados(){
        System.out.println("Aluguel: "+ codigo);
        System.out.println("Data Inicio: "+ dataInicio);
        System.out.println("Data Fim: "+ dataFim);
        imovel.exibeDados();
        System.out.println("Nome Cliente: " + cliente.getNome());
    }
}
