
public class Imovel
{

    //atributos
    private int codigo;
    private String descricao;
    private double precoAluguel;
    private int qtMinMeses;
    

    //construtor
    public Imovel(int c, String d, double p, int q){
        codigo = c;
        descricao = d;
        precoAluguel = p;
        qtMinMeses = q;
    }
    
    //método exibeDados
    public void exibeDados(){
        System.out.println("Dados do Imovel");
        System.out.println("Codigo: "+ codigo);
        System.out.println("Descricao: "+ descricao);
        System.out.println("Preco do Aluguel: " + precoAluguel);
        System.out.println("Qtde. Min. Meses: "+ qtMinMeses);
    }
}
